# ComfyUI-NodeRenamer v0.1.1

Frontend-only batch rename utility for ComfyUI nodes.

## Features

- Rename selected nodes as `BaseName + incrementing index`
- Sequential rename supports selectable sort order:
  - **Position (Top-Left -> Right -> Down)** (default)
  - **Current Node Name** using natural numeric sorting (`Node_2` before `Node_10`)
  - **Selection Order**
- Position sorting groups nodes with nearby Y positions into a row, then sorts each row left to right
- Numeric `Padding`
  - Padding `0` -> `1, 2, 3...`
  - Padding `2` -> `001, 002, 003...`
  - Padding `5` -> `000001, 000002, 000003...`
- Prefix / Suffix
- Find / Replace, optionally case-sensitive
- Case conversion
  - `snake_case`
  - `camelCase`
  - `PascalCase`
- Preview before applying
- Undo last rename (up to 20 operations in the current browser session)

## Install

Copy this folder into:

`ComfyUI/custom_nodes/ComfyUI-NodeRenamer`

Then restart ComfyUI and reload the browser page.

## Usage

1. Select one or more nodes.
2. Open **Node Renamer** from the selection toolbox or top menu.
3. For **Sequential**, choose the desired **Sort Order**.
4. Preview the result.
5. Click **Apply**.

## Sort Order

### Position (Top-Left -> Right -> Down)

Designed for box/range selections. Nodes are grouped into visual rows from top to bottom, and each row is sorted from left to right.

### Current Node Name

Sorts by the current visible title (`node.title`) using natural numeric comparison. For example:

`Camera_1, Camera_2, Camera_10`

### Selection Order

Preserves explicit click-selection history when available. If another operation creates a multi-selection without normal node selection callbacks, Node Renamer falls back to ComfyUI's current selected-node enumeration.

## Notes

This extension changes only the visible node title (`node.title`). It does not alter node type, inputs, outputs, widgets, or backend execution behavior.
